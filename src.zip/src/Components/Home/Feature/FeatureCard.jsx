// import React from 'react';

// export default function FeatureCard() {
//   return (
//     <div className="flex-1 bg-white rounded-2xl shadow-md hover:shadow-xl p-8 transition-all duration-300 ease-in-out transform hover:-translate-y-1">
//       <div className="flex justify-center items-center w-16 h-16 mx-auto mb-6 rounded-xl bg-gradient-to-br from-blue-50 to-blue-100">
//        {props.icon}
//       </div>
//       <div className="space-y-3">
//         <h3 className="text-xl font-bold text-gray-800">{props.title}</h3>
//         <p className="text-sm font-medium text-blue-600 uppercase tracking-wider">
//           {props.subtitle}
//         </p>
//         <p className="text-gray-600 leading-relaxed">
//           {props.description}
//         </p>
//       </div>
//     </div>
//   );
// }
